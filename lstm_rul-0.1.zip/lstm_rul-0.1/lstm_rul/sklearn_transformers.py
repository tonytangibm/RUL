import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.preprocessing import MinMaxScaler

#Custom Transformer that extracts columns passed as argument to its constructor
class MyETL( BaseEstimator, TransformerMixin ):
    #Class Constructor
    def __init__(self, window_size, num_engine, col_to_remove = None, X = None, y = None  ):
        print("In init, window_size " + str(window_size))
        self._col_to_remove = col_to_remove
        self._window_size = window_size
        self._num_engine = num_engine
        #pass

    #Return self nothing else to do here
    def fit(self, df, y = None ):
        print("in fit")
        # Step 1, remove un-used columns
        if self._col_to_remove != None :
            df = df.drop(self._col_to_remove, axis=1)

        # Step 2, construct X and y
        X = self.construct_X(df, self._num_engine, self._window_size )

        # Step 3, scale X
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled = scaler.fit(X)
        self._scaler = scaler
        return scaled.reshape(X.shape[0], 1, X.shape[1])

    #Return self nothing else to do here
    def transform(self, df, y = None ):
        print("In transform, df.shape = " + str(df.shape))
        # Step 1, remove un-used columns
        if self._col_to_remove != None :
            df = df.drop(self._col_to_remove, axis=1)

        # Step 2, construct X and y
        X = self.construct_X(df, self._num_engine, self._window_size )

        print(X.shape)
        scaled = self._scaler.transform(X)
        return scaled.reshape(X.shape[0], 1, X.shape[1])

    #Method that describes what we need this transformer to do
    def fit_transform(self, df, y = None ):
        print ("In fit_transform")
        # Step 1, remove un-used columns
        if self._col_to_remove != None :
            df = df.drop(self._col_to_remove, axis=1)

        # Step 2, construct X and y
        X = self.construct_X(df, self._num_engine, self._window_size )
        #y = self.construct_y(df, self._num_engine, self._window_size )

        print(X.shape)
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled = scaler.fit_transform(X)
        self._scaler = scaler
        return scaled.reshape(X.shape[0], 1, X.shape[1])



    def construct_X(self, data, num_engine, window_size ) :
        df = pd.DataFrame()
        RUL_cap = 130 # cap RUL at 130

        for i in range(num_engine) :
          df1 = data[data['engine_no'] == i+1]
          df2 = df1.drop(['engine_no'], axis=1)
          df3 = self.series_to_supervised(df2, window_size, 1)
          df = df.append(df3)
        return df

    # convert series to supervised learning
    def series_to_supervised(self, data, n_in=1, n_out=1, dropnan=True):
        n_vars = 1 if type(data) is list else data.shape[1]
        df = pd.DataFrame(data)
        cols, names = list(), list()
        # input sequence (t-n, ... t-1)
        for i in range(n_in, 0, -1):
            cols.append(df.shift(i))
            names += [( df.columns[j] + '(t-%d)' % ( i)) for j in range(n_vars)]
        # forecast sequence (t, t+1, ... t+n)
        for i in range(0, n_out):
            cols.append(df.shift(-i))
            if i == 0:
                names += [(df.columns[j] + '(t)' ) for j in range(n_vars)]
            else:
                names += [(df.columns[j] + '(t+%d)' % ( i)) for j in range(n_vars)]
        # put it all together
        agg = pd.concat(cols, axis=1)
        agg.columns = names
        # drop rows with NaN values
        if dropnan:
            agg.dropna(inplace=True)
        return agg
