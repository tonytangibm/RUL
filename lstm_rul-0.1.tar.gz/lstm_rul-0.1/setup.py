from setuptools import setup

VERSION='0.1'
setup(name='lstm_rul',
      version=VERSION,
      description='Custom transformer for RUL predictions',
      url='https://github.com/tonytangibm/RUL/',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=[
            'lstm_rul'
      ],
      zip_safe=False)
